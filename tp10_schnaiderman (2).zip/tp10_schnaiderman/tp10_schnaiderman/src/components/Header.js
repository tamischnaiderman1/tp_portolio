import React from "react";
import "./header.css"


const Header = () => {

  return (
    <button class="btn">

    <div class="wrapper">
        <p class="text">Tami Schnaiderman </p><br/>
        
        <p class="text">Estudiante de Ort </p>

        <div class="flower flower1">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
        <div class="flower flower2">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
        <div class="flower flower3">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
        <div class="flower flower4">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
        <div class="flower flower5">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
        <div class="flower flower6">
            <div class="petal one"></div>
            <div class="petal two"></div>
            <div class="petal three"></div>
            <div class="petal four"></div>
        </div>
    </div>
</button>

    /*<div className={classes.typedContainer}>
      <div container justify="center">
        <img className={classes.avatar} src={avatar} alt="Tami Schnaiderman" />
      </div>
      <Typography className={classes.title} variant="h4">
        <Typed strings={["Tami Schnaiderman"]} typeSpeed={40} />
      </Typography>

      <Typography className={classes.subtitle} variant="h5">
        <Typed
          strings={[
            "Estudiante de ORT Informatica"
          ]}
          typeSpeed={40}
          backSpeed={50}
          loop
        />
      </Typography>
    </div>*/
  );
};

export default Header;
