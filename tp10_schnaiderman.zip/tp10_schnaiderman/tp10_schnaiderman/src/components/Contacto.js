import React from "react"
import "./contacto.css"

const Contacto = () => {

    return (
        <form className="form">
            <div className="flex">
                <label>
                    <input className="input" type="text" placeholder=""  />
                    <span>First name</span>
                </label>

                <label>
                    <input className="input" type="text" placeholder=""/>
                    <span>Last name</span>
                </label>
            </div>

            <label>
                <input className="input" type="email" placeholder=""  />
                <span>Email</span>
            </label>

            <label>
                <input className="input" placeholder="" type="tel"  />
                <span>Contact number</span>
            </label>
            <label>
                <textarea className="input01" placeholder="" rows="6" required=""></textarea>
                <span>Message</span>
            </label>

            <button href="#" className="fancy">
                <span className="top-key"></span>
                <span className="text">SUBMIT</span>
                <span className="bottom-key-1"></span>
                <span className="bottom-key-2"></span>
            </button>
        </form>
    );
};
export default Contacto;
