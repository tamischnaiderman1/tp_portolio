import React from "react"
import "./contacto.css"
const Contact = () => {
  return (
 
    <form class="form">
    
    <div class="flex">
        <label>
            <input class="input" type="text" placeholder="" required=""/>
            <span>first name</span>
        </label>

        <label>
            <input class="input" type="text" placeholder="" required=""/>
            <span>last name</span>
        </label>
    </div>  
            
    <label>
        <input class="input" type="email" placeholder="" required=""/>
        <span>email</span>
    </label> 
        
    <label>
        <input class="input" placeholder="" type="tel" required=""/>
        <span>contact number</span>
    </label>
    <label>
        <textarea class="input01" placeholder="" rows="3" required=""></textarea>
        <span>message</span>
    </label>
    
    <button href="#" class="fancy">
      <span class="top-key"></span>
      <span class="text">submit</span>
      <span class="bottom-key-1"></span>
      <span class="bottom-key-2"></span>
    </button>
</form>
  );
};

export default Contact;
