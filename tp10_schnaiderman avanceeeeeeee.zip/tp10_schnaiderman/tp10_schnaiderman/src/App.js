import React from "react";
import { Route, Switch } from "react-router-dom";
import Home from "./components/index";
import Navbar from "./components/Navbar";
import Portfolio from "./components/Portfolio";
import Contacto from "./components/Contacto";

import "./App.css";

function App() {
  return (
    <React.Fragment>
      <Navbar >
      <Switch>
      <Route exact path="/index" component={Home} />
        <Route exact path="/portfolio" component={Portfolio} />
        <Route exact path="/contacto" component={Contacto} />
      </Switch>
      </Navbar  >
    </React.Fragment>
  );
}

export default App;
