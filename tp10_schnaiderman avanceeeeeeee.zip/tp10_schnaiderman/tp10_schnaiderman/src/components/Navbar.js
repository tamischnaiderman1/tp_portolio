import React, { useState } from "react";
import { Link } from "react-router-dom";
import Contacto from "./Contacto";
import avatar from "../avatar.png";
import styles from "./navbar.css";

import Portfolio from "./Portfolio";

const menuItems = [
  { list: <Portfolio />, listText: "Portfolio", listPath: "/portfolio" },
  { list: <Contacto />, listText: "Contacto", listPath: "/contacto" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);


  const sideList = () => (
    <div className={styles.menuSliderContainer}>
      <div className={styles.avatar2}>
        <img src={avatar} alt="Tami Schnaiderman" />
      </div>
      <ul>
        {menuItems.map((item, i) => (
          <li key={i} className={styles.listItem} onClick={() => setOpen(false)}>
            <Link to={item.listPath}>
              {item.list}
              <span>{item.listText}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <div>
      <div component="nav">
        <div position="static" className={styles.appbar}>
          <div>
            <button onClick={() => setOpen(true)} className="cursor-pointer duration-200 hover:scale-125 active:scale-100" title="Go Back">
              </button>          
            <p variant="h5" className={styles.title}>
              Portfolio
            </p>
          </div>
        </div>
      </div>
      <div open={open} anchor="right" onClose={() => setOpen(false)}>
        {sideList()}
      
      </div>
    </div>
  );
};

export default Navbar;
