import React from "react";
import "./header.css"


const Header = () => {

  return (
    <button className="btn">

    <div className="wrapper">
        <p className="text">Tami Schnaiderman </p><br/>
        
        <p className="text">Estudiante de Ort </p>

        <div className="flower flower1">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
        <div className="flower flower2">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
        <div className="flower flower3">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
        <div className="flower flower4">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
        <div className="flower flower5">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
        <div className="flower flower6">
            <div className="petal one"></div>
            <div className="petal two"></div>
            <div className="petal three"></div>
            <div className="petal four"></div>
        </div>
    </div>
</button>

    /*<div className={classes.typedContainer}>
      <div container justify="center">
        <img className={classes.avatar} src={avatar} alt="Tami Schnaiderman" />
      </div>
      <Typography className={classes.title} variant="h4">
        <Typed strings={["Tami Schnaiderman"]} typeSpeed={40} />
      </Typography>

      <Typography className={classes.subtitle} variant="h5">
        <Typed
          strings={[
            "Estudiante de ORT Informatica"
          ]}
          typeSpeed={40}
          backSpeed={50}
          loop
        />
      </Typography>
    </div>*/
  );
};

export default Header;
