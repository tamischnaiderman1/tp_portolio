import React from 'react';
import { useCreaciones } from '../context/CreacionesContext';
import Creacion from './Creacion';

const Favoritos = () => {
    const { favoritos } = useCreaciones();

    return (
        <div>
            <h2>Favoritos</h2>
            <div className="creaciones-container">
                {favoritos.map((creacion) => (
                    <Creacion key={creacion.id} creacion={creacion} />
                ))}
            </div>
        </div>
    );
};

export default Favoritos;