import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import Navbar from "./Navbar";
import Portfolio from "./Portfolio";

const Home = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navbar />} />
        <Route index element={<Portfolio />} />
        <Route index element={<Footer />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Home;
