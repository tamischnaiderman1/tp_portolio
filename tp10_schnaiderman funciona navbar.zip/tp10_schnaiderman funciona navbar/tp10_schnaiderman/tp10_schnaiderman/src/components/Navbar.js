import React, { useState } from "react";
import { Link } from "react-router-dom";
import Contacto from "./Contacto";
import avatar from "../avatar.png";
import styles from "./navbar.css";

import Portfolio from "./Portfolio";

const menuItems = [
  { list: <Portfolio />, listText: "Portfolio", listPath: "/portfolio" },
  { list: <Contacto />, listText: "Contacto", listPath: "/contacto" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);


  const sideList = () => (
    <div className={styles.menuSliderContainer}>
      <div className={styles.avatar2}>
        <img src={avatar} alt="Tami Schnaiderman" />
      </div>
      <ul>
        {menuItems.map((item, i) => (
          <li key={i} className={styles.listItem} onClick={() => setOpen(false)}>
            <Link to={item.listPath}>
              {item.list}
              <span>{item.listText}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <div>
      <nav>
        <ul position="static" className="appbar">
          <li>
            <Link to="/Portfolio">Portfolio</Link>
          </li>
          <li>
            <Link to="/Contacto">Contacto</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
