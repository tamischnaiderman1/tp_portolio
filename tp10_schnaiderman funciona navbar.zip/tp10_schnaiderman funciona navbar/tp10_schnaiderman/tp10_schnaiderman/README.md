#### Installing

Clone the repository using following command or download

```

#### To install dependency

```
npm install
```

#### To start the server

```
npm start
```

#### For Production Build

```
npm run build
```


